function ealertintrojs(){
    alert('sachin')
    document.body.style.backgroundColor="green"
}
function econfirmintrojs(){
    confirm('sachin')
    document.body.style.backgroundColor="red"
}
function epromptintrojs(){
    prompt('sachin')
    document.body.style.backgroundColor="yellow"
}